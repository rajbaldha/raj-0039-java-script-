

  try {
    const PI = 77.25877888478954;
    //PI = 3.14;
    document.write(PI);

  }
  catch (err) {
    document.write(err);
  }