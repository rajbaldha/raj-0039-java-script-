

var a = 100;
document.write(a, "\n");


let b = 200;
document.write(b, "\n");


document.write(c, "\n");
var c = 50;

document.write(x);
let x = 75;

const z = 75;
z=200;
document.write(z);
z=1000;
document.write(z);